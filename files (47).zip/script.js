const API_SEARCH = "https://www.themealdb.com/api/json/v1/1/search.php?s=";
const API_LOOKUP = "https://www.themealdb.com/api/json/v1/1/lookup.php?i=";

const form = document.getElementById('searchForm');
const input = document.getElementById('searchInput');
const results = document.getElementById('results');
const status = document.getElementById('status');
const overlay = document.getElementById('overlay');
const modalContent = document.getElementById('modalContent');
const chips = document.getElementById('chips');

function setStatus(msg, isError){
  status.textContent = msg;
  status.style.display = msg ? 'block' : 'none';
  status.className = 'status' + (isError ? ' error' : '');
}

async function search(term){
  results.innerHTML = '';
  setStatus('Looking through the pantry…');
  try{
    const res = await fetch(API_SEARCH + encodeURIComponent(term));
    if(!res.ok) throw new Error('Request failed');
    const data = await res.json();
    if(!data.meals){
      setStatus(`No recipes found for "${term}". Try another search.`, true);
      return;
    }
    setStatus('');
    renderCards(data.meals);
  }catch(err){
    setStatus('Something went wrong reaching the recipe database. Please try again.', true);
  }
}

function renderCards(meals){
  results.innerHTML = meals.map(m => `
    <button class="card" data-id="${m.idMeal}">
      <img src="${m.strMealThumb}/preview" alt="${m.strMeal}" loading="lazy">
      <div class="body">
        <div class="tag">${m.strArea || 'Recipe'}${m.strCategory ? ' · ' + m.strCategory : ''}</div>
        <h3>${m.strMeal}</h3>
      </div>
    </button>
  `).join('');
}

results.addEventListener('click', e => {
  const card = e.target.closest('.card');
  if(card) openRecipe(card.dataset.id);
});

async function openRecipe(id){
  modalContent.innerHTML = '<div style="padding:40px; text-align:center; color:#8a8377;">Loading recipe…</div>';
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
  try{
    const res = await fetch(API_LOOKUP + id);
    const data = await res.json();
    const meal = data.meals[0];
    renderModal(meal);
  }catch(err){
    modalContent.innerHTML = '<button class="close-btn" id="closeBtn">×</button><div style="padding:40px;">Could not load this recipe.</div>';
    document.getElementById('closeBtn').addEventListener('click', closeModal);
  }
}

function renderModal(meal){
  const ingredients = [];
  for(let i = 1; i <= 20; i++){
    const ing = meal['strIngredient' + i];
    const measure = meal['strMeasure' + i];
    if(ing && ing.trim()){
      ingredients.push(`<li><span>${ing}</span><span>${measure || ''}</span></li>`);
    }
  }
  modalContent.innerHTML = `
    <button class="close-btn" id="closeBtn" aria-label="Close">×</button>
    <img src="${meal.strMealThumb}" alt="${meal.strMeal}">
    <div class="modal-body">
      <div class="tag">${meal.strArea || ''}${meal.strCategory ? ' · ' + meal.strCategory : ''}</div>
      <h2>${meal.strMeal}</h2>
      <h4>Ingredients</h4>
      <ul class="ingredients">${ingredients.join('')}</ul>
      <h4>Method</h4>
      <div class="instructions">${meal.strInstructions || 'No instructions available.'}</div>
    </div>
  `;
  document.getElementById('closeBtn').addEventListener('click', closeModal);
}

function closeModal(){
  overlay.classList.remove('open');
  document.body.style.overflow = '';
}
overlay.addEventListener('click', e => { if(e.target === overlay) closeModal(); });
document.addEventListener('keydown', e => { if(e.key === 'Escape') closeModal(); });

form.addEventListener('submit', e => {
  e.preventDefault();
  const term = input.value.trim();
  if(term) search(term);
});

chips.addEventListener('click', e => {
  const chip = e.target.closest('.chip');
  if(chip){
    input.value = chip.dataset.q;
    search(chip.dataset.q);
  }
});

// Initial load
search('chicken');
